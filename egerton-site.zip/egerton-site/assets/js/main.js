/* Egerton.us — shared JS */

document.addEventListener('DOMContentLoaded', function () {

  /* ---- Mobile nav toggle ---- */
  const toggle = document.querySelector('.nav-toggle');
  const links  = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      links.classList.toggle('open');
      const open = links.classList.contains('open');
      toggle.setAttribute('aria-expanded', open);
    });
  }

  /* ---- Mark active nav link ---- */
  const path = window.location.pathname.replace(/\/$/, '') || '/index';
  document.querySelectorAll('.nav-links a').forEach(function (a) {
    const href = a.getAttribute('href').replace(/\/$/, '');
    if (href === path || (path === '' && href === '/index') || (path.endsWith('index') && href === '/index')) {
      a.classList.add('active');
    }
  });

  /* ---- Contact form (mailto fallback) ---- */
  const form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const name    = form.querySelector('#name').value.trim();
      const email   = form.querySelector('#email').value.trim();
      const url     = form.querySelector('#url') ? form.querySelector('#url').value.trim() : '';
      const message = form.querySelector('#message').value.trim();
      const subject = encodeURIComponent('Inquiry from egerton.us — ' + name);
      const body    = encodeURIComponent(
        'Name: ' + name + '\n' +
        'Email: ' + email + '\n' +
        (url ? 'Website: ' + url + '\n' : '') +
        '\nMessage:\n' + message
      );
      window.location.href = 'mailto:baker@egerton.us?subject=' + subject + '&body=' + body;
      document.getElementById('form-success').style.display = 'block';
    });
  }

  /* ---- Intersection observer for fade-up elements ---- */
  const observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'none';
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.fade-up').forEach(function (el) {
    observer.observe(el);
  });

});
